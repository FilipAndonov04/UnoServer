package bg.sofia.uni.fmi.mjt.uno.errorlogger;

public interface ErrorLogger {

    void log(Exception exception);

}
