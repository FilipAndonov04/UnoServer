package bg.sofia.uni.fmi.mjt.uno.game.gamelogs.spectator;

public interface Spectator {

    void onEvent(String event);

}
