package bg.sofia.uni.fmi.mjt.uno.game.exeption;

public class GameException extends Exception {

    public GameException(String message) {
        super(message);
    }

    public GameException(String message, Throwable cause) {
        super(message, cause);
    }

}
