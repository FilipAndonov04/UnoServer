package bg.sofia.uni.fmi.mjt.uno.user.command;

public class RefreshCommand implements Command {

    @Override
    public void execute() {
    }

}
