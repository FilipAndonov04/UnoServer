package bg.sofia.uni.fmi.mjt.uno.database.account.saver;

import bg.sofia.uni.fmi.mjt.uno.database.account.Database;

import java.io.IOException;
import java.io.Writer;

public interface DatabaseSaver {

    /**
     * Saves a database to a character stream
     *
     * @param database The database to be saved
     * @param writer The character stream
     * @throws IOException If an error occurs while saving the database
     * @throws IllegalArgumentException If the reader is null
     */
    void save(Database database, Writer writer) throws IOException;

}
