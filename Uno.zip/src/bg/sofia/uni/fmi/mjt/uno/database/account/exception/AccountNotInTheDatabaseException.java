package bg.sofia.uni.fmi.mjt.uno.database.account.exception;

public class AccountNotInTheDatabaseException extends Exception {

    public AccountNotInTheDatabaseException(String message) {
        super(message);
    }

    public AccountNotInTheDatabaseException(String message, Throwable cause) {
        super(message, cause);
    }

}
