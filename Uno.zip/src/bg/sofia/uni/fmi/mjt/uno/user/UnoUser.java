package bg.sofia.uni.fmi.mjt.uno.user;

import bg.sofia.uni.fmi.mjt.uno.database.account.Database;
import bg.sofia.uni.fmi.mjt.uno.database.account.Account;
import bg.sofia.uni.fmi.mjt.uno.database.account.exception.UsernameTakenException;
import bg.sofia.uni.fmi.mjt.uno.game.Game;
import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;
import bg.sofia.uni.fmi.mjt.uno.game.UnoGame;
import bg.sofia.uni.fmi.mjt.uno.game.card.Color;
import bg.sofia.uni.fmi.mjt.uno.game.deck.Deck;
import bg.sofia.uni.fmi.mjt.uno.game.gamelogs.UnoGameLogs;
import bg.sofia.uni.fmi.mjt.uno.game.player.Player;
import bg.sofia.uni.fmi.mjt.uno.game.player.UnoPlayer;
import bg.sofia.uni.fmi.mjt.uno.database.game.GameDatabase;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class UnoUser implements User {

    private final Database database;
    private final GameDatabase gameDatabase;

    Account account;

    Game createdGame;
    Game game;
    Player player;

    public UnoUser(Database database, GameDatabase gameDatabase) {
        this.database = database;
        this.gameDatabase = gameDatabase;
    }

    @Override
    public void register(String username, String password) throws InvalidUserOperation {
        try {
            database.addAccount(new Account(username, password));
        } catch (UsernameTakenException e) {
            throw new InvalidUserOperation("Username is already taken!", e);
        }
    }

    @Override
    public void login(String username, String password) throws InvalidUserOperation {
        if (isLoggedIn()) {
            throw new InvalidUserOperation("User is already logged in!");
        }

        Account temp = new Account(username, password);
        if (database.containsAccount(temp)) {
            account = temp;
        } else if (!database.isFreeUsername(username)) {
            throw new InvalidUserOperation("Wrong password!");
        } else {
            throw new InvalidUserOperation("There is no user with that username!");
        }
    }

    @Override
    public void logout() throws InvalidUserOperation {
        assertIsLoggedIn();
        account = null;
    }

    @Override
    public String listGames(GameStatus status) throws InvalidUserOperation {
        assertIsLoggedIn();
        return gameDatabase.getGamesAsString(status);
    }

    @Override
    public void createGame(int playersCount, int gameId) throws InvalidUserOperation {
        assertIsLoggedIn();
        if (createdGame != null) {
            throw new InvalidUserOperation("User has already created a game!");
        }
        if (!gameDatabase.isFreeId(gameId)) {
            throw new InvalidUserOperation("Game id must be unique!");
        }

        try {
            createdGame = new UnoGame(Deck.getTheClassicalUnoDeck(), gameId, new UnoGameLogs(), playersCount);
            gameDatabase.addGame(createdGame);
        } catch (Exception e) {
            createdGame = null;
            throw e;
        }
    }

    @Override
    public void joinGame(int gameId, String displayName) throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsNotInAGame();
        Game temp = gameDatabase.getGame(gameId);
        if (temp == null) {
            throw new InvalidUserOperation("There is no game with that id!");
        }
        if (temp.getGameStatus() != GameStatus.AVAILABLE) {
            throw new InvalidUserOperation("The game is not available!");
        }
        player = new UnoPlayer(displayName == null ? account.username() : displayName);
        if (!temp.addPlayer(player)) {
            player = null;
            throw new InvalidUserOperation("The game is full!");
        }
        game = temp;
    }

    @Override
    public void startGame() throws InvalidUserOperation {
        assertIsLoggedIn();
        if (createdGame == null) {
            throw new InvalidUserOperation("User did not create a game!");
        }
        if (game != createdGame) {
            throw new InvalidUserOperation("User is not in the game!");
        }
        if (!createdGame.getGameStatus().equals(GameStatus.AVAILABLE)) {
            throw new InvalidUserOperation("The game is not available!");
        }
        createdGame.start();
        gameDatabase.updateGameStatus(createdGame);
    }

    @Override
    public String showHand() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        if (player.isHandEmpty()) {
            throw new InvalidUserOperation("User has already won!");
        }
        return player.getHandToString();
    }

    @Override
    public String showLastCard() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        return game.viewCurrentCard();
    }

    @Override
    public void acceptEffect() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        game.acceptEffect(player);
    }

    @Override
    public void drawCard() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        game.drawCard(player);
    }

    @Override
    public void playCard(int cardIndex) throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        game.playRegularCard(player, cardIndex);
    }

    @Override
    public void playChooseColor(int cardIndex, Color newColor) throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        game.playChooseColor(player, cardIndex, newColor);
    }

    @Override
    public void playPlusFour(int cardIndex, Color newColor) throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        game.playPlusFour(player, cardIndex, newColor);
    }

    @Override
    public String showPlayedCards() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        return game.showPlayedCards();
    }

    @Override
    public void leaveGame() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInGame();
        doIfGameIsOver();
        game.leave(player);
        game = null;
        player = null;
    }

    @Override
    public String spectateGame() throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsInLiveGame();
        if (!player.isHandEmpty()) {
            throw new InvalidUserOperation("User cannot spectate while playing!");
        }

        return game.getSummary();
    }

    @Override
    public String getGameSummary(int gameId) throws InvalidUserOperation {
        assertIsLoggedIn();
        assertUserIsNotInAGame();
        Game temp = gameDatabase.getGame(gameId);
        if (temp == null) {
            throw new InvalidUserOperation("There is no game with that id!");
        }
        if (!temp.isEnded()) {
            throw new InvalidUserOperation("User can only get a summary on ended games!");
        }

        return temp.getSummary();
    }

    private boolean isLoggedIn() {
        return account != null;
    }

    private void assertIsLoggedIn() throws InvalidUserOperation {
        if (!isLoggedIn()) {
            throw new InvalidUserOperation("User is not logged in!");
        }
    }

    private void assertUserIsNotInAGame() throws InvalidUserOperation {
        if (game != null) {
            throw new InvalidUserOperation("User is already in a game!");
        }
    }

    private void assertUserIsInGame() throws InvalidUserOperation {
        if (game == null) {
            throw new InvalidUserOperation("User is not in a game!");
        }
    }

    private void assertUserIsInLiveGame() throws InvalidUserOperation {
        if (game == null || game.getGameStatus() != GameStatus.STARTED) {
            throw new InvalidUserOperation("User is not in a live game!");
        }
    }

    private void doIfGameIsOver() {
        if (game == null || !game.isEnded()) {
            return;
        }
        gameDatabase.updateGameStatus(game);
        if (game == createdGame) {
            createdGame = null;
        }
    }

}
