package bg.sofia.uni.fmi.mjt.uno.database.account;

import bg.sofia.uni.fmi.mjt.uno.database.account.exception.UsernameTakenException;
import bg.sofia.uni.fmi.mjt.uno.database.account.exception.AccountNotInTheDatabaseException;

import java.util.Set;

public class InMemoryDatabase implements Database {

    private final Set<Account> accounts;

    public InMemoryDatabase(Set<Account> accounts) {
        if (accounts == null) {
            throw new IllegalArgumentException("Null accounts given!");
        }

        this.accounts = accounts;
    }

    @Override
    public synchronized void addAccount(Account account) throws UsernameTakenException {
        assertNotNull(account, "Account cannot be null!");

        if (!isFreeUsername(account.username())) {
            throw new UsernameTakenException(
                "There is already an account with that username in the database!");
        }

        accounts.add(account);
    }

    @Override
    public synchronized void removeAccount(Account account) throws AccountNotInTheDatabaseException {
        assertNotNull(account, "Account cannot be null!");

        if (!containsAccount(account)) {
            throw new AccountNotInTheDatabaseException("There is no such account in the database!");
        }

        accounts.remove(account);
    }

    @Override
    public synchronized boolean containsAccount(Account account) {
        assertNotNull(account, "Account cannot be null!");

        return accounts.contains(account);
    }

    @Override
    public synchronized boolean isFreeUsername(String username) {
        assertNotNull(username, "Username cannot be null!");

        return accounts.stream()
            .map(Account::username)
            .noneMatch(e -> e.equals(username));
    }

    @Override
    public synchronized Set<Account> getAccounts() {
        return accounts;
    }

    private void assertNotNull(Object object, String message) {
        if (object == null) {
            throw new IllegalArgumentException(message);
        }
    }

}
