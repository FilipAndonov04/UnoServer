package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;
import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

import java.io.PrintWriter;

public class ListGamesCommand implements Command {

    public static final String COMMAND_TEXT = "list-games";
    private static final String STATUS_ID = "--status=";
    private static final int MIN_TEXT_COUNT = 1;
    private static final int MAX_TEXT_COUNT = 2;

    private final User user;
    private final GameStatus status;
    private final PrintWriter out;

    public ListGamesCommand(User user, GameStatus status, PrintWriter out) {
        this.user = user;
        this.status = status;
        this.out = out;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        out.println(user.listGames(status));
    }

    public static Command fromString(String line, User user, PrintWriter out) {
        String[] words = line.split(" ");
        if (words.length != MIN_TEXT_COUNT && words.length != MAX_TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (words.length == 1) {
            return new ListGamesCommand(user, null, out);
        }

        if (!words[index].startsWith(STATUS_ID)) {
            throw new InvalidUserInput("Invalid command!");
        }
        GameStatus status = fromString(words[index].substring(STATUS_ID.length()));
        return new ListGamesCommand(user, status, out);
    }

    private static GameStatus fromString(String string) {
        return switch (string) {
            case "started" -> GameStatus.STARTED;
            case "ended" -> GameStatus.ENDED;
            case "available" -> GameStatus.AVAILABLE;
            case "all" -> null;
            default -> throw new InvalidUserInput("Invalid status!");
        };
    }

}
