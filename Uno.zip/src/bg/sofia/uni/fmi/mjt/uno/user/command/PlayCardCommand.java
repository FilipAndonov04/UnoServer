package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class PlayCardCommand implements Command {

    public static final String COMMAND_TEXT = "play";
    private static final String CARD_ID_TEXT = "--card-id=";
    private static final int TEXT_COUNT = 2;

    private final User user;
    private final int cardId;

    public PlayCardCommand(User user, int cardId) {
        this.user = user;
        this.cardId = cardId;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.playCard(cardId);
    }

    public static Command fromString(String line, User user) {
        String[] words = line.split(" ");
        if (words.length != TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(CARD_ID_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int cardId = Integer.parseInt(words[index].substring(CARD_ID_TEXT.length()));
        return new PlayCardCommand(user, cardId);
    }

}
