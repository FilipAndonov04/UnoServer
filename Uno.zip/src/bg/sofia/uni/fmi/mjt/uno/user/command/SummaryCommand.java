package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

import java.io.PrintWriter;

public class SummaryCommand implements Command {

    public static final String COMMAND_TEXT = "summary";
    private static final String GAME_ID_TEXT = "--game-id=";
    private static final int TEXT_COUNT = 2;

    private final User user;
    private final int gameId;
    private final PrintWriter out;

    public SummaryCommand(User user, int gameId, PrintWriter out) {
        this.user = user;
        this.gameId = gameId;
        this.out = out;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        out.println(user.getGameSummary(gameId));
    }

    public static Command fromString(String line, User user, PrintWriter out) {
        String[] words = line.split(" ");
        if (words.length != TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(GAME_ID_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int gameId = Integer.parseInt(words[index].substring(GAME_ID_TEXT.length()));
        return new SummaryCommand(user, gameId, out);
    }

}
