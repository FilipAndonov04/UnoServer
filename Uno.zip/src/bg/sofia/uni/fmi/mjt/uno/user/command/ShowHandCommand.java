package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

import java.io.PrintWriter;

public class ShowHandCommand implements Command {

    public static final String COMMAND_TEXT = "show-hand";

    private final User user;
    private final PrintWriter out;

    public ShowHandCommand(User user, PrintWriter out) {
        this.user = user;
        this.out = out;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        out.println(user.showHand());
    }

    public static Command fromString(String line, User user, PrintWriter out) {
        return line.equals(COMMAND_TEXT) ? new ShowHandCommand(user, out) : null;
    }

}
