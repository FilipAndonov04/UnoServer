package bg.sofia.uni.fmi.mjt.uno.client;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    private static final int SERVER_PORT = 9999;

    private static final String ERROR_FILE_NAME = "ClientErrors.txt";

    private static final String END_MESSAGE = "!END!";

    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", SERVER_PORT);
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner scanner = new Scanner(System.in)) {

            while (true) {
                System.out.print("Enter command: ");
                String message = scanner.nextLine();

                if ("quit".equals(message)) {
                    break;
                }

                writer.println(message);

                String reply = reader.readLine();
                while (!reply.equals(END_MESSAGE)) {
                    System.out.println(reply);
                    reply = reader.readLine();
                }
            }

        } catch (IOException e) {
            saveErrorToFile(e);
            System.out.println("There is a problem with the server!");
        }
    }

    private static void saveErrorToFile(Exception exception) {
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(ERROR_FILE_NAME, true), true)) {
            printWriter.println(exception.getMessage());
            exception.printStackTrace(printWriter);
            printWriter.println();
        } catch (IOException e) {
            System.out.println("Something is totally wrong!");
        }
    }

}
