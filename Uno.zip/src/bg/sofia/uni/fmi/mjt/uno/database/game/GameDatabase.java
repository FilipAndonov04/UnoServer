package bg.sofia.uni.fmi.mjt.uno.database.game;

import bg.sofia.uni.fmi.mjt.uno.game.Game;
import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;

import java.util.Set;

public interface GameDatabase {

    Set<Game> getGames(GameStatus status);

    String getGamesAsString(GameStatus status);

    Set<Game> getAllGames();

    void addGame(Game game);

    void updateGameStatus(Game game);

    boolean isFreeId(int id);

    Game getGame(int id);

}
