package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

import java.io.PrintWriter;

public interface Command {

    void execute() throws InvalidUserOperation;

    static Command create(String line, User user, PrintWriter out) throws InvalidUserOperation {
        String first = line.split(" ")[0];
        Command command = createFromFirstWord(first, line, user, out);
        if (command == null) {
            throw new InvalidUserInput("Invalid user command!");
        }
        return command;
    }

    private static Command createFromFirstWord(String command, String line, User user, PrintWriter out) {
        return switch (command) {
            case AcceptEffectCommand.COMMAND_TEXT -> AcceptEffectCommand.fromString(line, user);
            case CreateGameCommand.COMMAND_TEXT -> CreateGameCommand.fromString(line, user);
            case DrawCardCommand.COMMAND_TEXT -> DrawCardCommand.fromString(line, user);
            case JoinGameCommand.COMMAND_TEXT -> JoinGameCommand.fromString(line, user);
            case LeaveGameCommand.COMMAND_TEXT -> LeaveGameCommand.fromString(line, user);
            case ListGamesCommand.COMMAND_TEXT -> ListGamesCommand.fromString(line, user, out);
            case LoginCommand.COMMAND_TEXT -> LoginCommand.fromString(line, user);
            case LogoutCommand.COMMAND_TEXT -> LogoutCommand.fromString(line, user);
            case PlayCardCommand.COMMAND_TEXT -> PlayCardCommand.fromString(line, user);
            case PlayChooseColorCommand.COMMAND_TEXT -> PlayChooseColorCommand.fromString(line, user);
            case PlayPlusFourCommand.COMMAND_TEXT -> PlayPlusFourCommand.fromString(line, user);
            case RegisterCommand.COMMAND_TEXT -> RegisterCommand.fromString(line, user);
            case ShowHandCommand.COMMAND_TEXT -> ShowHandCommand.fromString(line, user, out);
            case ShowPlayedCardsCommand.COMMAND_TEXT -> ShowPlayedCardsCommand.fromString(line, user, out);
            case ShowLastCardCommand.COMMAND_TEXT -> ShowLastCardCommand.fromString(line, user, out);
            case SpectateGameCommand.COMMAND_TEXT -> SpectateGameCommand.fromString(line, user, out);
            case StartGameCommand.COMMAND_TEXT -> StartGameCommand.fromString(line, user);
            case SummaryCommand.COMMAND_TEXT -> SummaryCommand.fromString(line, user, out);
            default -> throw new InvalidUserInput("Invalid user command!");
        };
    }

}
