package bg.sofia.uni.fmi.mjt.uno.database.account.saver;

import bg.sofia.uni.fmi.mjt.uno.database.account.Account;
import bg.sofia.uni.fmi.mjt.uno.database.account.Database;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;

public class InMemoryDatabaseSaver implements DatabaseSaver {

    private static final String USERNAME_TEXT = "username";
    private static final String PASSWORD_TEXT = "password";
    private static final char EQUALS_SIGN = '=';
    private static final char DELIMITER_SIGN = ' ';

    @Override
    public void save(Database database, Writer writer) throws IOException {
        assertNotNull(database, "Database cannot be null!");
        assertNotNull(writer, "Writer cannot be null!");
        synchronized (database) {
            try (BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
                for (Account account : database.getAccounts()) {
                    bufferedWriter.write(getStringFromAccount(account));
                    bufferedWriter.newLine();
                }
                bufferedWriter.flush();
            } catch (IOException exception) {
                throw new IOException("Error while saving the database!", exception);
            }
        }
    }

    private String getStringFromAccount(Account account) {
        return USERNAME_TEXT + EQUALS_SIGN + account.username() + DELIMITER_SIGN +
            PASSWORD_TEXT + EQUALS_SIGN + account.password();
    }

    private void assertNotNull(Object object, String message) {
        if (object == null) {
            throw new IllegalArgumentException(message);
        }
    }

}
