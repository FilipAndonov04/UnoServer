package bg.sofia.uni.fmi.mjt.uno.server;

import bg.sofia.uni.fmi.mjt.uno.database.account.Database;
import bg.sofia.uni.fmi.mjt.uno.database.account.loader.DatabaseLoader;
import bg.sofia.uni.fmi.mjt.uno.database.account.loader.InMemoryDatabaseLoader;
import bg.sofia.uni.fmi.mjt.uno.database.account.saver.DatabaseSaver;
import bg.sofia.uni.fmi.mjt.uno.database.account.saver.InMemoryDatabaseSaver;
import bg.sofia.uni.fmi.mjt.uno.database.game.GameDatabase;
import bg.sofia.uni.fmi.mjt.uno.database.game.UnoGameDatabase;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server extends Thread {

    private static final int SERVER_PORT = 9999;
    private static final String DATABASE_FILE_NAME = "database.txt";
    private static final String ERROR_FILE_NAME = "serverErrors.txt";

    private static Server instance;

    private final Database database;
    private final GameDatabase gameDatabase = new UnoGameDatabase();
    private boolean isRunning;
    private ServerSocket serverSocket;

    private Server() {
        DatabaseLoader loader = new InMemoryDatabaseLoader();
        try {
            database = loader.load(new FileReader(DATABASE_FILE_NAME));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static synchronized Server getInstance() {
        if (instance == null) {
            instance = new Server();
        }
        return instance;
    }

    public synchronized Database getDatabase() {
        return database;
    }

    public synchronized GameDatabase getGameDatabase() {
        return gameDatabase;
    }

    public synchronized boolean isRunning() {
        return isRunning;
    }

    @Override
    public void run() {
        isRunning = true;
        try (ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
             ExecutorService executor = Executors.newCachedThreadPool()) {

            Socket clientSocket;
            while (isRunning) {
                clientSocket = serverSocket.accept();

                ClientRequestHandler clientHandler = new ClientRequestHandler(clientSocket);
                executor.execute(clientHandler);
            }
        } catch (IOException e) {
            saveDatabase();
            throw new RuntimeException("There is a problem with the server socket", e);
        }
        saveDatabase();
    }

    public synchronized void shutDown() {
        isRunning = false;
    }

    public synchronized void saveDatabase() {
        DatabaseSaver saver = new InMemoryDatabaseSaver();
        try {
            saver.save(database, new FileWriter(DATABASE_FILE_NAME));
        } catch (IOException e) {
            handleException(e);
        }
    }

    public void handleException(Exception exception) {
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(ERROR_FILE_NAME, true), true)) {
            printWriter.println(exception.getMessage());
            printWriter.println();
            exception.printStackTrace(printWriter);
        } catch (IOException e) {
            System.out.println("Something is totally wrong!");
            e.printStackTrace();
        }
        System.out.println(exception.getMessage());
        exception.printStackTrace();
    }

    public static void main(String[] args) {
        Server server = Server.getInstance();
        server.start();

        try (Scanner scanner = new Scanner(System.in)) {
            while (server.isRunning()) {
                System.out.print("Enter message: ");
                String message = scanner.nextLine();

                if (message.equals("shutdown")) {
                    server.shutDown();
                }
            }
        }
    }

}
