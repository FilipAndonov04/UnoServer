package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class CreateGameCommand implements Command {

    public static final String COMMAND_TEXT = "create-game";
    private static final String PLAYER_COUNT_TEXT = "--number-of-players=";
    private static final String GAME_ID_TEXT = "--game-id=";
    private static final int TEXT_COUNT = 3;

    private final User user;
    private final int playerCount;
    private final int gameId;

    public CreateGameCommand(User user, int playerCount, int gameId) {
        this.user = user;
        this.playerCount = playerCount;
        this.gameId = gameId;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.createGame(playerCount, gameId);
    }

    public static Command fromString(String line, User user) {
        String[] words = line.split(" ");
        if (words.length != TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(PLAYER_COUNT_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int playerCount = Integer.parseInt(words[index++].substring(PLAYER_COUNT_TEXT.length()));
        if (!words[index].startsWith(GAME_ID_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int gameId = Integer.parseInt(words[index].substring(GAME_ID_TEXT.length()));
        return new CreateGameCommand(user, playerCount, gameId);
    }

}
