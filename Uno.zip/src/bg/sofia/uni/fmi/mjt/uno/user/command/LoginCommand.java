package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class LoginCommand implements Command {

    public static final String COMMAND_TEXT = "login";
    private static final String USERNAME_TEXT = "--username=";
    private static final String PASSWORD_TEXT = "--password=";
    private static final int TEXT_COUNT = 3;

    private final User user;
    private final String username;
    private final String password;

    public LoginCommand(User user, String username, String password) {
        this.user = user;
        this.username = username;
        this.password = password;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.login(username, password);
    }

    public static Command fromString(String line, User user) {
        String[] words = line.split(" ");
        if (words.length != TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(USERNAME_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        String username = words[index++].substring(USERNAME_TEXT.length());
        if (!words[index].startsWith(PASSWORD_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        String password = words[index].substring(PASSWORD_TEXT.length());
        return new LoginCommand(user, username, password);
    }

}
