package bg.sofia.uni.fmi.mjt.uno.game.gamelogs;

import bg.sofia.uni.fmi.mjt.uno.game.card.Card;
import bg.sofia.uni.fmi.mjt.uno.game.player.Player;

import java.util.List;

public interface GameLogs {

    /**
     * Returns the current scoreboard of the game where the first one is the winner and the last one is the loser
     *
     * @return List of the players who finished
     */
    List<Player> getScoreboard();

    List<Player> getLeavers();

    /**
     * Returns text representation of all the played moves of the game
     *
     * @return List of all the played moves
     */
    List<String> getAllMoves();

    /**
     * Returns text representation of all the played cards in the game
     *
     * @return String of all the played cards
     */
    String getPlayedCards();

    String getSummary();

    /**
     * Adds a player to the scoreboard
     *
     * @param player The player to be added
     */
    void addPlayerToScoreboard(Player player);

    void addPlayerToLeavers(Player player);

    /**
     * Adds a new move to the logs
     *
     * @param players List of the players in the game
     * @param currentCard The card that was lastly played
     * @param currentPlayerIndex The index of current player
     */
    void addNextMove(List<Player> players, Card currentCard, int currentPlayerIndex);

    void addCurrentCard(Card currentCard);

}
