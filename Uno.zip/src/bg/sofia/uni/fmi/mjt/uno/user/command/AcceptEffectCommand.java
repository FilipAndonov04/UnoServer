package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class AcceptEffectCommand implements Command {

    public static final String COMMAND_TEXT = "accept-effect";

    private final User user;

    public AcceptEffectCommand(User user) {
        this.user = user;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.acceptEffect();
    }

    public static Command fromString(String line, User user) {
        return line.equals(COMMAND_TEXT) ? new AcceptEffectCommand(user) : null;
    }

}
