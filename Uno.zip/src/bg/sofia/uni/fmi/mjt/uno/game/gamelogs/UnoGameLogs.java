package bg.sofia.uni.fmi.mjt.uno.game.gamelogs;

import bg.sofia.uni.fmi.mjt.uno.game.card.Card;
import bg.sofia.uni.fmi.mjt.uno.game.player.Player;

import java.util.ArrayList;
import java.util.List;

public class UnoGameLogs implements GameLogs {

    private final List<Player> scoreboard = new ArrayList<>();
    private final List<Player> leavers = new ArrayList<>();
    private final List<String> allMoves = new ArrayList<>();
    private final StringBuilder playedCards = new StringBuilder();

    @Override
    public List<String> getAllMoves() {
        return allMoves;
    }

    @Override
    public String getPlayedCards() {
        return playedCards.toString();
    }

    @Override
    public List<Player> getScoreboard() {
        return scoreboard;
    }

    @Override
    public List<Player> getLeavers() {
        return leavers;
    }

    @Override
    public String getSummary() {
        StringBuilder summary = new StringBuilder("Scoreboard:" + System.lineSeparator());
        summary.append(playerListToString(scoreboard))
            .append("Leavers:")
            .append(System.lineSeparator())
            .append(playerListToString(leavers))
            .append(System.lineSeparator());

        for (String string : allMoves) {
            summary.append(string).append(System.lineSeparator());
        }
        summary.append(System.lineSeparator());
        return summary.toString();
    }

    @Override
    public void addPlayerToScoreboard(Player player) {
        scoreboard.add(player);
    }

    @Override
    public void addPlayerToLeavers(Player player) {
        leavers.add(player);
    }

    @Override
    public void addNextMove(List<Player> players, Card currentCard, int currentPlayerIndex) {
        StringBuilder text = new StringBuilder("The current card is: ");
        text.append(currentCard.getText())
            .append(System.lineSeparator());
        for (Player player : players) {
            text.append("Player ")
                .append(player.getUsername())
                .append(" has ")
                .append(player.getCardsInHandCount())
                .append(" cards : ")
                .append(player.getHandToString())
                .append(System.lineSeparator());
        }
        text.append("It is turn to player number ")
            .append(currentPlayerIndex + 1)
            .append(System.lineSeparator());
        allMoves.add(text.toString());
    }

    @Override
    public void addCurrentCard(Card currentCard) {
        playedCards.insert(0, ' ').insert(0, currentCard.getText());
    }

    private String playerListToString(List<Player> playerList) {
        StringBuilder builder = new StringBuilder();
        for (Player player : playerList) {
            builder.append(player.getUsername()).append(System.lineSeparator());
        }
        return builder.toString();
    }

}
