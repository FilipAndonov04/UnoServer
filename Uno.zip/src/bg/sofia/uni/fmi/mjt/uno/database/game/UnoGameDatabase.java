package bg.sofia.uni.fmi.mjt.uno.database.game;

import bg.sofia.uni.fmi.mjt.uno.game.Game;
import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class UnoGameDatabase implements GameDatabase {

    private final Map<GameStatus, Set<Game>> games = new HashMap<>();
    private final Map<Integer, Game> gameById = new HashMap<>();

    public UnoGameDatabase() {
        for (GameStatus status : GameStatus.values()) {
            games.put(status, new HashSet<>());
        }
    }

    @Override
    public synchronized Set<Game> getGames(GameStatus status) {
        if (status == null) {
            return getAllGames();
        }
        return Collections.unmodifiableSet(games.get(status));
    }

    @Override
    public synchronized String getGamesAsString(GameStatus status) {
        StringBuilder builder = new StringBuilder();
        for (Game game : getGames(status)) {
            builder.append(game.toString()).append(System.lineSeparator());
        }
        return builder.toString();
    }

    @Override
    public synchronized Set<Game> getAllGames() {
        Set<Game> gameSet = new HashSet<>();
        for (GameStatus status : GameStatus.values()) {
            gameSet.addAll(games.get(status));
        }
        return Collections.unmodifiableSet(gameSet);
    }

    @Override
    public synchronized void addGame(Game game) {
        games.get(game.getGameStatus()).add(game);
        gameById.put(game.getId(), game);
    }

    @Override
    public synchronized void updateGameStatus(Game game) {
        for (GameStatus status : GameStatus.values()) {
            games.get(status).remove(game);
        }
        addGame(game);
    }

    @Override
    public synchronized boolean isFreeId(int id) {
        return !gameById.containsKey(id);
    }

    @Override
    public synchronized Game getGame(int id) {
        return gameById.get(id);
    }

}
