package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class LeaveGameCommand implements Command {

    public static final String COMMAND_TEXT = "leave";

    private final User user;

    public LeaveGameCommand(User user) {
        this.user = user;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.leaveGame();
    }

    public static Command fromString(String line, User user) {
        return line.equals(COMMAND_TEXT) ? new LeaveGameCommand(user) : null;
    }

}
