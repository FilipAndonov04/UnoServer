package bg.sofia.uni.fmi.mjt.uno.server;

import bg.sofia.uni.fmi.mjt.uno.game.exeption.GameException;
import bg.sofia.uni.fmi.mjt.uno.user.UnoUser;
import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.command.Command;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientRequestHandler implements Runnable {

    private static final String END_MESSAGE = "!END!";

    private final Socket socket;
    private final User user = new UnoUser(Server.getInstance().getDatabase(), Server.getInstance().getGameDatabase());

    public ClientRequestHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        Thread.currentThread().setName("Client Request Handler for " + socket.getRemoteSocketAddress());

        try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (!Server.getInstance().isRunning()) {
                    out.println("Server has shut down! Have a nice day!");
                    return;
                }

                handleInput(inputLine, out);
            }
        } catch (Exception e) {
            Server.getInstance().handleException(e);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                Server.getInstance().handleException(e);
            }
        }
    }

    private void handleInput(String inputLine, PrintWriter out) {
        Command command;
        try {
            command = Command.create(inputLine, user, out);
        } catch (InvalidUserInput | InvalidUserOperation e) {
            out.println(e.getMessage());
            out.println(END_MESSAGE);
            return;
        }
        try {
            command.execute();
        } catch (InvalidUserOperation | GameException e) {
            out.println(e.getMessage());
            out.println(END_MESSAGE);
            return;
        }

        out.println("Command executed successfully!");
        out.println(END_MESSAGE);
    }

}
