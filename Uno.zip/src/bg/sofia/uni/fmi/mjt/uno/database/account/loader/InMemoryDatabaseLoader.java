package bg.sofia.uni.fmi.mjt.uno.database.account.loader;

import bg.sofia.uni.fmi.mjt.uno.database.account.Account;
import bg.sofia.uni.fmi.mjt.uno.database.account.Database;
import bg.sofia.uni.fmi.mjt.uno.database.account.InMemoryDatabase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Set;
import java.util.stream.Collectors;

public class InMemoryDatabaseLoader implements DatabaseLoader {

    private static final char EQUALS_SIGN = '=';
    private static final char DELIMITER_SIGN = ' ';
    private static final int COUNT_OF_WORDS_IN_LINE = 2;

    @Override
    public Database load(Reader reader) throws IOException {
        if (reader == null) {
            throw new IllegalArgumentException("Reader cannot be null!");
        }

        try (BufferedReader bufferedReader = new BufferedReader(reader)) {
            Set<Account> accounts = bufferedReader.lines()
                .map(this::getAccountFromLine)
                .collect(Collectors.toSet());
            return new InMemoryDatabase(accounts);
        } catch (IOException exception) {
            throw new IOException("Error while loading the database!", exception);
        }
    }

    private Account getAccountFromLine(String line) {
        assertLine(line);

        int delimiterIndex = line.indexOf(DELIMITER_SIGN);
        String username = line.substring(line.indexOf(EQUALS_SIGN) + 1, delimiterIndex);
        String password = line.substring(line.indexOf(EQUALS_SIGN, delimiterIndex) + 1);
        return new Account(username, password);
    }

    private void assertLine(String line) {
        int counterEqualSign = 0;
        int counterDelimiterSign = 0;
        for (char ch : line.toCharArray()) {
            if (ch == EQUALS_SIGN) {
                counterEqualSign++;
            } else if (ch == DELIMITER_SIGN) {
                counterDelimiterSign++;
            }
        }
        if (counterEqualSign != COUNT_OF_WORDS_IN_LINE || counterDelimiterSign != COUNT_OF_WORDS_IN_LINE - 1) {
            throw new IllegalArgumentException("Reading from an invalid line!");
        }
    }

}
