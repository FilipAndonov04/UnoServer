package bg.sofia.uni.fmi.mjt.uno.database.account.loader;

import bg.sofia.uni.fmi.mjt.uno.database.account.Database;

import java.io.IOException;
import java.io.Reader;

public interface DatabaseLoader {

    /**
     * Loads a database from a character stream
     *
     * @param reader The character stream
     * @return The loaded database
     * @throws IOException If an error occurs while loading the database
     * @throws IllegalArgumentException If the reader is null
     */
    Database load(Reader reader) throws IOException;

}
