package bg.sofia.uni.fmi.mjt.uno.game;

import bg.sofia.uni.fmi.mjt.uno.game.card.Color;
import bg.sofia.uni.fmi.mjt.uno.game.card.Value;
import bg.sofia.uni.fmi.mjt.uno.game.deck.Deck;
import bg.sofia.uni.fmi.mjt.uno.game.deck.UnoDeck;
import bg.sofia.uni.fmi.mjt.uno.game.card.Card;
import bg.sofia.uni.fmi.mjt.uno.game.exeption.GameException;
import bg.sofia.uni.fmi.mjt.uno.game.gamelogs.GameLogs;
import bg.sofia.uni.fmi.mjt.uno.game.player.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;

public class UnoGame implements Game {

    private static final int STARTING_CARDS_PER_PLAYER = 7;
    private static final int PLAYER_COUNT_WHEN_REVERSE_ACTS_LIKE_SKIP = 2;
    private static final int PLUS_TWO_ADDED_CARDS = 2;
    private static final int PLUS_FOUR_ADDED_CARDS = 4;

    private static final String CANNOT_MAKE_ILLEGAL_MOVE_MESSAGE = "Player cannot make an illegal move!";

    private final GameLogs gameLogs;
    private final int id;
    private final int maxPlayerCount;

    private GameStatus gameStatus = GameStatus.AVAILABLE;

    private final List<Player> players = new ArrayList<>();
    private int playersLeft;
    private int currentPlayerIndex = 0;
    private int toAddToNextPlayer = 1;

    private Deck drawingDeck;
    private Deck playedCards = new UnoDeck();

    private Card currentCard;
    private Card facadeCard;

    private boolean hasEffectToAccept = false;

    public UnoGame(Deck deck, int id, GameLogs gameLogs, int maxPlayerCount) {
        if (maxPlayerCount > MAX_PLAYERS) {
            throw new GameException("User cannot create a game with more than " +
                Game.MAX_PLAYERS + " players in a game!");
        }

        drawingDeck = deck;
        this.id = id;
        this.gameLogs = gameLogs;
        this.maxPlayerCount = maxPlayerCount;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public int getMaxPlayers() {
        return maxPlayerCount;
    }

    @Override
    public synchronized GameStatus getGameStatus() {
        return gameStatus;
    }

    @Override
    public synchronized void start() {
        if (players.size() < 2) {
            throw new GameException("The game cannot start with less than two players!");
        }

        gameStatus = GameStatus.STARTED;
        prepareGame();
    }

    @Override
    public boolean isEnded() {
        return gameStatus.equals(GameStatus.ENDED);
    }

    @Override
    public boolean addPlayer(Player player) {
        if (players.size() == maxPlayerCount) {
            return false;
        }
        return players.add(player);
    }

    @Override
    public synchronized void playRegularCard(Player player, int cardIndex) {
        assertIsNotEnded();
        assertIsInTheGame(player);
        assertIsPLayersTurn(player);
        assertHasNoEffectsToAccept();
        if (!player.getPlayableCardsIndexes(facadeCard).contains(cardIndex)) {
            throw new GameException(CANNOT_MAKE_ILLEGAL_MOVE_MESSAGE);
        }
        if (player.getHand().get(cardIndex).isWild()) {
            throw new GameException("Cannot play Wild card!");
        }

        updateCurrentCard(player.playCard(cardIndex), null);
        log();
        gameLogs.addCurrentCard(facadeCard);
    }

    @Override
    public synchronized void playChooseColor(Player player, int cardIndex, Color newColor) {
        assertIsNotEnded();
        assertIsInTheGame(player);
        playWildCard(player, cardIndex, newColor, Value.CHOOSE_COLOR);
        log();
        gameLogs.addCurrentCard(facadeCard);
    }

    @Override
    public synchronized void playPlusFour(Player player, int cardIndex, Color newColor) {
        assertIsNotEnded();
        assertIsInTheGame(player);
        playWildCard(player, cardIndex, newColor, Value.PLUS_FOUR);
        log();
        gameLogs.addCurrentCard(facadeCard);
    }

    @Override
    public synchronized void drawCard(Player player) {
        assertIsNotEnded();
        assertIsInTheGame(player);
        assertIsPLayersTurn(player);
        assertHasNoEffectsToAccept();
        if (canPlayerPlay()) {
            throw new GameException("Player cannot draw when he can play a card!");
        }

        givePlayerCards(player, 1);
        goToNextPlayer();
        log();
    }

    @Override
    public synchronized void acceptEffect(Player player) {
        assertIsNotEnded();
        assertIsInTheGame(player);
        assertIsPLayersTurn(player);
        if (!hasEffectsToAccept()) {
            throw new GameException("Player does not have effects to accept!");
        }

        hasEffectToAccept = false;
        givePlayerCards(player, getEffectsToAcceptCardsCount());
        goToNextPlayer();
        log();
    }

    @Override
    public synchronized Player getCurrentPlayer() {
        assertIsNotEnded();
        return players.get(currentPlayerIndex);
    }

    @Override
    public synchronized String viewCurrentCard() {
        assertIsNotEnded();
        return facadeCard.getText();
    }

    @Override
    public synchronized String showPlayedCards() {
        return gameLogs.getPlayedCards();
    }

    @Override
    public synchronized String getSummary() {
        return gameLogs.getSummary();
    }

    @Override
    public synchronized void leave(Player player) {
        assertIsInTheGame(player);
        if (gameStatus.equals(GameStatus.AVAILABLE)) {
            players.remove(player);
            return;
        }
        if (isEnded()) {
            gameLogs.addPlayerToScoreboard(player);
            return;
        }

        while (!player.isHandEmpty()) {
            playedCards.addCard(player.playCard(0));
        }
        gameLogs.addPlayerToLeavers(player);
        playersLeft--;
        if (playersLeft == 1) {
            gameStatus = GameStatus.ENDED;
            return;
        }
        if (isPlayersTurn(player)) {
            goToNextPlayer();
        }
        log();
    }

    @Override
    public String toString() {
        return "Game : [id = " + id + ", status = " + gameStatus + "]";
    }

    private void prepareGame() {
        Collections.shuffle(players);

        drawingDeck.shuffle();
        for (Player player : players) {
            givePlayerCards(player, STARTING_CARDS_PER_PLAYER);
        }

        chooseStartingCard();
        gameLogs.addNextMove(players, currentCard, currentPlayerIndex);
        gameLogs.addCurrentCard(currentCard);
    }

    private void chooseStartingCard() {
        currentCard = drawingDeck.drawCard();
        boolean shouldReshuffle = false;

        EnumSet<Value> validValue = EnumSet.range(Value.ZERO, Value.NINE);
        while (!validValue.contains(currentCard.value())) {
            shouldReshuffle = true;
            drawingDeck.addCard(currentCard);
            currentCard = drawingDeck.drawCard();
        }
        if (shouldReshuffle) {
            drawingDeck.shuffle();
        }

        facadeCard = currentCard;
        playersLeft = players.size();
    }

    private void givePlayerCards(Player player, int count) {
        for (int i = 0; i < count; i++) {
            reloadDeckIfNeeded();
            player.takeCard(drawingDeck.drawCard());
        }
    }

    private void reloadDeckIfNeeded() {
        if (drawingDeck.isEmpty()) {
            reloadDeck();
        }
    }

    private void reloadDeck() {
        Deck temp = drawingDeck;
        drawingDeck = playedCards;
        playedCards = temp;

        drawingDeck.shuffle();
    }

    private void reverseDirection() {
        toAddToNextPlayer *= -1;
    }

    private void goToNextPlayer() {
        if (isEnded()) {
            return;
        }

        currentPlayerIndex += toAddToNextPlayer;
        if (currentPlayerIndex == -1) {
            currentPlayerIndex = players.size() - 1;
        } else if (currentPlayerIndex == players.size()) {
            currentPlayerIndex = 0;
        }
        if (players.get(currentPlayerIndex).isHandEmpty()) {
            goToNextPlayer();
        }
    }

    private boolean isBlocked() {
        return currentCard.value().equals(Value.REVERSE) &&
            playersLeft == PLAYER_COUNT_WHEN_REVERSE_ACTS_LIKE_SKIP ||
            currentCard.value().equals(Value.SKIP);
    }

    private boolean isPlayersTurn(Player player) {
        return player.equals(getCurrentPlayer());
    }

    private void assertIsPLayersTurn(Player player) {
        if (!isPlayersTurn(player)) {
            throw new GameException("It is not player's turn!");
        }
    }

    private boolean hasEffectsToAccept() {
        return hasEffectToAccept;
    }

    private void assertHasNoEffectsToAccept() {
        if (hasEffectsToAccept()) {
            throw new GameException("Player has effects to accept and must accept them!");
        }
    }

    private int getEffectsToAcceptCardsCount() {
        if (currentCard.value().equals(Value.PLUS_FOUR)) {
            return PLUS_FOUR_ADDED_CARDS;
        }
        if (currentCard.value().equals(Value.PLUS_TWO)) {
            return PLUS_TWO_ADDED_CARDS;
        }
        return 0;
    }

    private boolean canPlayerPlay() {
        return !getCurrentPlayer().getPlayableCardsIndexes(currentCard).isEmpty();
    }

    private void updateCurrentCard(Card card, Color color) {
        playedCards.addCard(currentCard);
        currentCard = card;
        facadeCard = color == null ? card : new Card(color, card.value());

        if (currentCard.value().equals(Value.PLUS_FOUR) ||
            currentCard.value().equals(Value.PLUS_TWO)) {
            hasEffectToAccept = true;
        } else if (card.value().equals(Value.REVERSE)) {
            reverseDirection();
        }
        goToNextPlayer();
        if (isBlocked()) {
            goToNextPlayer();
        }
    }

    private void playWildCard(Player player, int cardIndex, Color newColor, Value value) {
        assertIsPLayersTurn(player);
        assertHasNoEffectsToAccept();
        if (!player.getHand().get(cardIndex).equals(new Card(Color.WILD, value))) {
            throw new GameException(CANNOT_MAKE_ILLEGAL_MOVE_MESSAGE);
        }

        if (newColor == null) {
            newColor = facadeCard.color();
        }
        updateCurrentCard(player.playCard(cardIndex), newColor);
    }

    private void log() {
        gameLogs.addNextMove(players, facadeCard, currentPlayerIndex);
    }

    private void assertIsNotEnded() {
        if (isEnded()) {
            throw new GameException("Game is over! Cannot play!");
        }
    }

    private void assertIsInTheGame(Player player) {
        if (!players.contains(player)) {
            throw new GameException("Player is not in the game!");
        }
    }

}
