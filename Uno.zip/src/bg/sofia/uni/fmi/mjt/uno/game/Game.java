package bg.sofia.uni.fmi.mjt.uno.game;

import bg.sofia.uni.fmi.mjt.uno.game.card.Color;
import bg.sofia.uni.fmi.mjt.uno.game.player.Player;

public interface Game {

    int MAX_PLAYERS = 10;

    int getId();

    int getMaxPlayers();

    GameStatus getGameStatus();

    void start();

    boolean isEnded();

    boolean addPlayer(Player player);

    void playRegularCard(Player player, int cardIndex);

    void playChooseColor(Player player, int cardIndex, Color newColor);

    void playPlusFour(Player player, int cardIndex, Color newColor);

    void drawCard(Player player);

    void acceptEffect(Player player);

    Player getCurrentPlayer();

    String viewCurrentCard();

    String showPlayedCards();

    String getSummary();

    void leave(Player player);
    
}
