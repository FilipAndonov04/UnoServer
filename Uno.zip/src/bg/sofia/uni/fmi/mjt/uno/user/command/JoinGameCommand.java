package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class JoinGameCommand implements Command {

    public static final String COMMAND_TEXT = "join";
    private static final String GAME_ID_TEXT = "--game-id=";
    private static final String DISPLAY_NAME_TEXT = "--display-name=";
    private static final int MIN_TEXT_COUNT = 2;
    private static final int MAX_TEXT_COUNT = 3;

    private final User user;
    private final int gameId;
    private final String displayName;

    public JoinGameCommand(User user, int gameId, String displayName) {
        this.user = user;
        this.displayName = displayName;
        this.gameId = gameId;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.joinGame(gameId, displayName);
    }

    public static Command fromString(String line, User user) {
        String[] words = line.split(" ");
        if (words.length != MIN_TEXT_COUNT && words.length != MAX_TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(GAME_ID_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int gameId = Integer.parseInt(words[index++].substring(GAME_ID_TEXT.length()));
        if (words.length == 2) {
            return new JoinGameCommand(user, gameId, null);
        }

        if (!words[index].startsWith(DISPLAY_NAME_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        String displayName = words[index].substring(DISPLAY_NAME_TEXT.length());
        return new JoinGameCommand(user, gameId, displayName);
    }

}
