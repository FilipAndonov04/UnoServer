package bg.sofia.uni.fmi.mjt.uno.game;

public enum GameStatus {

    STARTED,
    ENDED,
    AVAILABLE

}
