package bg.sofia.uni.fmi.mjt.uno.user.command;

import bg.sofia.uni.fmi.mjt.uno.game.card.Color;
import bg.sofia.uni.fmi.mjt.uno.user.User;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserInput;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public class PlayChooseColorCommand implements Command {

    public static final String COMMAND_TEXT = "play-choose";
    private static final String CARD_ID = "--card-id=";
    private static final String COLOR_TEXT = "--color=";
    private static final int MIN_TEXT_COUNT = 2;
    private static final int MAX_TEXT_COUNT = 3;

    private final User user;
    private final int cardId;
    private final Color color;

    public PlayChooseColorCommand(User user, int cardId, Color color) {
        this.user = user;
        this.cardId = cardId;
        this.color = color;
    }

    @Override
    public void execute() throws InvalidUserOperation {
        user.playChooseColor(cardId, color);
    }

    public static Command fromString(String line, User user) {
        String[] words = line.split(" ");
        if (words.length != MIN_TEXT_COUNT && words.length != MAX_TEXT_COUNT) {
            return null;
        }

        int index = 0;
        if (!words[index++].equals(COMMAND_TEXT)) {
            return null;
        }
        if (!words[index].startsWith(CARD_ID)) {
            throw new InvalidUserInput("Invalid command!");
        }
        int cardId = Integer.parseInt(words[index++].substring(CARD_ID.length()));
        if (words.length == 2) {
            return new PlayChooseColorCommand(user, cardId, null);
        }

        if (!words[index].startsWith(COLOR_TEXT)) {
            throw new InvalidUserInput("Invalid command!");
        }
        Color color = fromString(words[index].substring(COLOR_TEXT.length()));
        if (color == null) {
            throw new InvalidUserInput("Invalid color!");
        }
        return new PlayChooseColorCommand(user, cardId, color);
    }

    private static Color fromString(String string) {
        return switch (string) {
            case "red" -> Color.RED;
            case "green" -> Color.GREEN;
            case "yellow" -> Color.YELLOW;
            case "blue" -> Color.BLUE;
            default -> null;
        };
    }

}
