package bg.sofia.uni.fmi.mjt.uno.user;

import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;
import bg.sofia.uni.fmi.mjt.uno.game.card.Color;
import bg.sofia.uni.fmi.mjt.uno.user.exception.InvalidUserOperation;

public interface User {

    void register(String username, String password) throws InvalidUserOperation;

    void login(String username, String password) throws InvalidUserOperation;

    void logout() throws InvalidUserOperation;

    String listGames(GameStatus status) throws InvalidUserOperation;

    void createGame(int playersCount, int gameId) throws InvalidUserOperation;

    void joinGame(int gameId, String displayName) throws InvalidUserOperation;

    void startGame() throws InvalidUserOperation;

    String showHand() throws InvalidUserOperation;

    String showLastCard() throws InvalidUserOperation;

    void acceptEffect() throws InvalidUserOperation;

    void drawCard() throws InvalidUserOperation;

    void playCard(int cardIndex) throws InvalidUserOperation;

    void playChooseColor(int cardIndex, Color newColor) throws InvalidUserOperation;

    void playPlusFour(int cardIndex, Color newColor) throws InvalidUserOperation;

    String showPlayedCards() throws InvalidUserOperation;

    void leaveGame() throws InvalidUserOperation;

    String spectateGame() throws InvalidUserOperation;

    String getGameSummary(int gameId) throws InvalidUserOperation;

}
