package bg.sofia.uni.fmi.mjt.uno.database.account.saver;

import bg.sofia.uni.fmi.mjt.uno.database.account.Database;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.Writer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class InMemoryDatabaseSaverTest {

    @Test
    void testSaveWithNullWriter() {
        InMemoryDatabaseSaver saver = new InMemoryDatabaseSaver();

        assertThrows(IllegalArgumentException.class, () -> saver.save(Mockito.mock(Database.class), null),
            "Save should throw IllegalArgumentException when called with null writer!");
    }

    @Test
    void testSaveWithNullDatabase() {
        InMemoryDatabaseSaver saver = new InMemoryDatabaseSaver();

        assertThrows(IllegalArgumentException.class, () -> saver.save(null, Mockito.mock(Writer.class)),
            "Save should throw IllegalArgumentException when called with null database!");
    }

    // For local testing, creates a file
    /*@Test
    void testSaveInFile() throws IOException {
        Account acc = new Account("name", "pass");
        Account acc2 = new Account("name21", "passWord");
        Database database = Mockito.mock(Database.class);
        when(database.getAccounts()).thenReturn(Set.of(acc, acc2));

        InMemoryDatabaseSaver saver = new InMemoryDatabaseSaver();

        String fileName = "testSave.txt";
        if (Files.notExists(Path.of(fileName))) {
            Files.createFile(Path.of(fileName));
        }
        FileWriter writer = new FileWriter(fileName);
        saver.save(database, writer);

        Set<String> lines = new HashSet<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))) {
            lines = bufferedReader.lines()
                .collect(Collectors.toSet());
        }
        Set<String> ans = Set.of("username=" + acc.username() + ' ' + "password=" + acc.password(),
            "username=" + acc2.username() + ' ' + "password=" + acc2.password());
        assertEquals(ans, lines, "Save should save database correctly!");
    }*/

}
