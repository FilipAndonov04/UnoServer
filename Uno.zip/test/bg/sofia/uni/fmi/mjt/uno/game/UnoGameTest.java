package bg.sofia.uni.fmi.mjt.uno.game;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class UnoGameTest {

    @Test
    void testConstructorWithOnePlayer() {
        //assertThrows();
    }
}
