package bg.sofia.uni.fmi.mjt.uno.database.game;

import bg.sofia.uni.fmi.mjt.uno.game.Game;
import bg.sofia.uni.fmi.mjt.uno.game.GameStatus;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UnoGameDatabaseTest {

    private UnoGameDatabase database;
    private Game mockGame;

    @BeforeEach
    public void setUp() {
        database = new UnoGameDatabase();
        mockGame = mock(Game.class);
        when(mockGame.getId()).thenReturn(1);
        when(mockGame.getGameStatus()).thenReturn(GameStatus.AVAILABLE);
    }

    @Test
    public void testAddGameAdding() {
        database.addGame(mockGame);
        Set<Game> availableGames = database.getGames(GameStatus.AVAILABLE);
        assertTrue(availableGames.contains(mockGame), "Add game should add games correctly!");
    }

    @Test
    public void testAddGameAddsTheSameGame() {
        database.addGame(mockGame);
        assertEquals(mockGame, database.getGame(1), "Add game should add games correctly!");
    }

    @Test
    public void testGetGamesWithSameIsNotEmpty() {
        database.addGame(mockGame);
        Set<Game> games = database.getGames(GameStatus.AVAILABLE);
        assertFalse(games.isEmpty(), "Get games should not return empty set!");
    }

    @Test
    public void testGetGamesWithDifferentIsEmpty() {
        database.addGame(mockGame);
        Set<Game> games = database.getGames(GameStatus.ENDED);
        assertEquals(Set.of(), games, "Get games should return empty set!");
    }

    @Test
    public void testGetGamesAsString() {
        database.addGame(mockGame);
        when(mockGame.toString()).thenReturn("Mocked Game");
        String gamesString = database.getGamesAsString(GameStatus.AVAILABLE);
        assertTrue(gamesString.contains("Mocked Game"), "Get games as string should convert properly!");
    }

    @Test
    public void testGetGamesWithNullStatus() {
        Game mockGame2 = mock(Game.class);
        when(mockGame2.getId()).thenReturn(12);
        when(mockGame2.getGameStatus()).thenReturn(GameStatus.ENDED);
        database.addGame(mockGame);
        database.addGame(mockGame2);

        Set<Game> allGames = database.getAllGames();
        assertEquals(Set.of(mockGame, mockGame2), database.getGames(null),
            "Get games should return all games when called with null!");
    }

    @Test
    public void testGetAllGames() {
        Game mockGame2 = mock(Game.class);
        when(mockGame2.getId()).thenReturn(12);
        when(mockGame2.getGameStatus()).thenReturn(GameStatus.ENDED);
        database.addGame(mockGame);
        database.addGame(mockGame2);

        Set<Game> allGames = database.getAllGames();
        assertEquals(Set.of(mockGame, mockGame2), database.getAllGames(),
            "Get all games should return all games!");
    }

    @Test
    public void testUpdateGameStatus() {
        database.addGame(mockGame);
        when(mockGame.getGameStatus()).thenReturn(GameStatus.ENDED);
        database.updateGameStatus(mockGame);
        assertTrue(database.getGames(GameStatus.ENDED).contains(mockGame),
            "Update status should update status correctly!");
    }

    @Test
    public void testIsFreeId() {
        assertTrue(database.isFreeId(1),
            "IsFreeId should return true when there is no game with index 1!");
        database.addGame(mockGame);
        assertFalse(database.isFreeId(1),
            "IsFreeId should return true when there is a game with index 1!");
    }

    @Test
    public void testGetGameById() {
        assertNull(database.getGame(1),
            "GetGameById should return null when there is no game with that index!");
        database.addGame(mockGame);
        assertEquals(mockGame, database.getGame(1),
            "GetGameById should return the game with index 1!");
    }

}
