package bg.sofia.uni.fmi.mjt.uno.database.account.loader;

import bg.sofia.uni.fmi.mjt.uno.database.account.Account;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class InMemoryDatabaseLoaderTest {

    @Test
    void testLoadWithNullReader() {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();

        assertThrows(IllegalArgumentException.class, () -> loader.load(null),
            "Load should throw IllegalArgumentException when called with null reader!");
    }

    @Test
    void testLoadWithEmptyReader() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("");

        assertTrue(loader.load(reader).getAccounts().isEmpty(),
            "Load should return an empty database when called with empty reader!");
    }

    @Test
    void testLoadWithReaderWithOneLine() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("username=name password=pass");

        Account account = new Account("name", "pass");
        assertEquals(Set.of(account), loader.load(reader).getAccounts(),
            "Load should read accounts correctly!");
    }

    @Test
    void testLoadWithReaderWithInvalidLineWithNoEqualSignInTheUsername() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("usernamename password=pass");

        Account account = new Account("name", "pass");
        assertThrows(IllegalArgumentException.class, () -> loader.load(reader),
            "Load should throw IllegalArgumentException when reading an invalid line!");
    }

    @Test
    void testLoadWithReaderWithInvalidLineWithTwoEqualSignsInTheUsername() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("username==name password=pass");

        Account account = new Account("name", "pass");
        assertThrows(IllegalArgumentException.class, () -> loader.load(reader),
            "Load should throw IllegalArgumentException when reading an invalid line!");
    }

    @Test
    void testLoadWithReaderWithInvalidLineWithNoSpaceBetweenWords() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("username=namepassword=pass");

        Account account = new Account("name", "pass");
        assertThrows(IllegalArgumentException.class, () -> loader.load(reader),
            "Load should throw IllegalArgumentException when reading an invalid line!");
    }

    @Test
    void testLoadWithReaderWithInvalidLineWithNoPassword() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();
        Reader reader = new StringReader("username=name");

        Account account = new Account("name", "pass");
        assertThrows(IllegalArgumentException.class, () -> loader.load(reader),
            "Load should throw IllegalArgumentException when reading an invalid line!");
    }

    @Test
    void testLoadWithReaderWithThreeLines() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();

        String text = "username=name password=pass" + System.lineSeparator() +
            "username=name2 password=pass2" + System.lineSeparator() + "username=name3 password=pass3";
        Reader reader = new StringReader(text);

        Account account = new Account("name", "pass");
        Account account2 = new Account("name2", "pass2");
        Account account3 = new Account("name3", "pass3");
        assertEquals(Set.of(account, account2, account3), loader.load(reader).getAccounts(),
            "Load should read accounts correctly!");
    }

    @Test
    void testLoadWithReaderWithThreeLinesWithEndLineAtTheEnd() throws IOException {
        InMemoryDatabaseLoader loader = new InMemoryDatabaseLoader();

        String text = "username=name password=pass" + System.lineSeparator() + "username=name2 password=pass2" +
            System.lineSeparator() + "username=name3 password=pass3" + System.lineSeparator();
        Reader reader = new StringReader(text);

        Account account = new Account("name", "pass");
        Account account2 = new Account("name2", "pass2");
        Account account3 = new Account("name3", "pass3");
        assertEquals(Set.of(account, account2, account3), loader.load(reader).getAccounts(),
            "Load should read accounts correctly!");
    }

}
